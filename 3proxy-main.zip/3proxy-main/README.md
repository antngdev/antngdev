<p><!-- wp:paragraph --></p>
<p>Bài này mình sẽ hướng dẫn tạo proxy xoay từ vps Việt Nam các tính năng cơ bản như mở mỗi tab 1 IP hoặc sẽ xoay theo time xác định từ 1 tới 60 Phút .</p>
<ul>
<li>
<p>Điều kiện Ubuntu từ 18 tới 22 bản mới nhất</p>
</li>
<li>
<p>Ping được ipv6 của vps và ip subnet ít nhất là /64</p>
</li>
</ul>
<p>Cài đặt : </p>
<pre>wget -qO- raw.githubusercontent.com/khacnam/dev/main/sh.sh | bash</pre>
<p dir="auto" tabindex="-1">User : onet</p>
<p dir="auto" tabindex="-1">pass : onet</p>
<p dir="auto" tabindex="-1"><a id="user-content-port--1000-tới-port-2000" href="https://github.com/khacnam/dev#port--1000-t%E1%BB%9Bi-port-2000" aria-hidden="true"></a>Port : 1000 tới port 2000</p>
<p dir="auto" tabindex="-1"><a id="user-content-thời-gian-xoay-20-phút-đổi-ip-một-lần" class="anchor" href="https://github.com/khacnam/dev#th%E1%BB%9Di-gian-xoay-20-ph%C3%BAt-%C4%91%E1%BB%95i-ip-m%E1%BB%99t-l%E1%BA%A7n" aria-hidden="true"></a>Thời gian xoay 20 phút đổi ip một lần</p>
<p><!-- /wp:paragraph --></p>
